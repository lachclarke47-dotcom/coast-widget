package ca.lach.coastwidget;

/** Everything the widget shows, filled in by DataFetcher. */
public class Data {
    // Weather
    boolean hasWeather;
    double temp = Double.NaN, feels = Double.NaN, wind = Double.NaN, windDir = Double.NaN;
    int code;
    boolean isDay = true;
    int days;
    String[] dayNames = new String[5];
    int[] dayCodes = new int[5];
    double[] dayMax = new double[5];
    double[] dayMin = new double[5];

    // Surf (Jordan River)
    boolean hasSurf;
    double waveH = Double.NaN, waveP = Double.NaN, waveDir = Double.NaN, swellH = Double.NaN;
    double[] surfHourly = new double[0]; // next 48 hours

    // NQ futures
    boolean hasNq;
    double nqPrice = Double.NaN, nqPrev = Double.NaN;
    double[] nqCloses = new double[0]; // last 10h of 5-min closes

    // Other markets (daily % change)
    String[] qNames = {"NAS100", "S&P", "OIL"};
    double[] qChg = {Double.NaN, Double.NaN, Double.NaN};

    long updated;
}
