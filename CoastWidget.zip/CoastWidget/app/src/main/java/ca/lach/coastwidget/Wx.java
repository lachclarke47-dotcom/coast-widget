package ca.lach.coastwidget;

/** WMO weather codes to icons and labels. */
public class Wx {
    static String emoji(int c, boolean day) {
        if (c == 0) return day ? "☀️" : "🌙";
        if (c <= 2) return day ? "🌤️" : "☁️";
        if (c == 3) return "☁️";
        if (c == 45 || c == 48) return "🌫️";
        if (c >= 51 && c <= 57) return "🌦️";
        if (c >= 61 && c <= 67) return "🌧️";
        if (c >= 71 && c <= 77) return "❄️";
        if (c >= 80 && c <= 82) return "🌧️";
        if (c >= 85 && c <= 86) return "🌨️";
        if (c >= 95) return "⛈️";
        return "☁️";
    }

    static String label(int c) {
        if (c == 0) return "Clear";
        if (c == 1) return "Mostly clear";
        if (c == 2) return "Partly cloudy";
        if (c == 3) return "Overcast";
        if (c == 45 || c == 48) return "Fog";
        if (c >= 51 && c <= 57) return "Drizzle";
        if (c == 61) return "Light rain";
        if (c == 63) return "Rain";
        if (c >= 64 && c <= 67) return "Heavy rain";
        if (c >= 71 && c <= 77) return "Snow";
        if (c == 80) return "Showers";
        if (c >= 81 && c <= 82) return "Heavy showers";
        if (c >= 85 && c <= 86) return "Snow showers";
        if (c >= 95) return "Thunderstorm";
        return "Cloudy";
    }
}
