package ca.lach.coastwidget;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.PersistableBundle;

/**
 * Does the network refresh as a system job. Android grants network access to
 * jobs that declare they need it, whereas plain background broadcasts on
 * Samsung / Android 14+ can have their internet cut off (UnknownHostException).
 */
public class RefreshJob extends JobService {

    static final int JOB_ID = 4201;

    static void enqueue(Context c, boolean force) {
        JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        PersistableBundle extras = new PersistableBundle();
        extras.putBoolean("force", force);
        ComponentName cn = new ComponentName(c, RefreshJob.class);

        // Try an expedited job first (runs right away), fall back to a regular one.
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                JobInfo fast = new JobInfo.Builder(JOB_ID, cn)
                        .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                        .setExpedited(true)
                        .setExtras(extras)
                        .build();
                if (js.schedule(fast) == JobScheduler.RESULT_SUCCESS) return;
            } catch (Exception ignored) { }
        }
        try {
            JobInfo normal = new JobInfo.Builder(JOB_ID, cn)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setExtras(extras)
                    .build();
            js.schedule(normal);
        } catch (Exception ignored) { }
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        final boolean force = params.getExtras().getBoolean("force", false);
        final Context app = getApplicationContext();
        new Thread(() -> {
            try {
                Data dt = DataFetcher.fetch(app, force);
                AppWidgetManager m = AppWidgetManager.getInstance(app);
                int[] ids = m.getAppWidgetIds(new ComponentName(app, CoastWidget.class));
                if (ids != null) {
                    for (int id : ids) CoastWidget.draw(app, m, id, dt);
                }
            } catch (Throwable ignored) {
            } finally {
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }
}
