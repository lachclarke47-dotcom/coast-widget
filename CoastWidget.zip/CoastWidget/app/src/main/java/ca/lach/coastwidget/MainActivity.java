package ca.lach.coastwidget;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

/** Opening the app just explains how to add the widget, and refreshes it. */
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        t.setPadding(p, p * 3, p, p);
        t.setTextSize(18);
        t.setTextColor(0xFFFFFFFF);
        t.setBackgroundColor(0xFF0B2F5B);
        t.setText("🌊 Coast Widget is installed.\n\n"
                + "To add it: long-press your home screen → Widgets → Coast Widget → drag it to the top of the screen.\n\n"
                + "Long-press it and drag the handles to make it full width.\n\n"
                + "Markets update every minute while your screen is on. Weather and surf update every 30 minutes. Tap the widget to refresh everything.\n\n"
                + "Tip: Settings → Apps → Coast Widget → Battery → Unrestricted, so Samsung doesn't pause the updates.");
        setContentView(t);
        sendBroadcast(new Intent(this, CoastWidget.class).setAction(CoastWidget.ACTION_REFRESH));
    }
}
