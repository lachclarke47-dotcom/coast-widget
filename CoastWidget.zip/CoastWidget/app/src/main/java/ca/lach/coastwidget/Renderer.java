package ca.lach.coastwidget;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/** Draws the whole widget (except the live clock) into one bitmap. */
public class Renderer {

    static final int WHITE = 0xFFFFFFFF;
    static final int SOFT = 0xB3FFFFFF;
    static final int DIM = 0x80FFFFFF;
    static final int CYAN = 0xFF4DD0E1;
    static final int AQUA = 0xFF80DEEA;
    static final int AMBER = 0xFFFFCC80;
    static final int GREEN = 0xFF00E676;
    static final int MINT = 0xFF69F0AE;
    static final int RED = 0xFFFF5252;

    float d; // pixels per dp
    int W, H;
    Canvas cv;

    static Bitmap render(Data dt, int w, int h, float density) {
        Renderer r = new Renderer();
        r.d = density;
        r.W = w;
        r.H = h;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        r.cv = new Canvas(bmp);
        r.draw(dt);
        return bmp;
    }

    // ---------- helpers ----------

    Paint text(float sizeDp, int color, int weight) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(sizeDp * d);
        p.setColor(color);
        if (weight == 0) p.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        else if (weight == 1) p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        else p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return p;
    }

    Paint emojiPaint(float sizeDp) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(sizeDp * d);
        return p;
    }

    static void fit(Paint p, String s, float maxW) {
        while (p.measureText(s) > maxW && p.getTextSize() > 6) p.setTextSize(p.getTextSize() * 0.92f);
    }

    static String one(double v) {
        return String.format(Locale.US, "%.1f", v);
    }

    static String deg(double v) {
        return Double.isNaN(v) ? "--°" : Math.round(v) + "°";
    }

    static String pct(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return "--";
        return (v >= 0 ? "▲" : "▼") + String.format(Locale.US, "%.2f%%", Math.abs(v * 100));
    }

    static String compass(double deg) {
        if (Double.isNaN(deg)) return "";
        String[] n = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        double x = ((deg % 360) + 360) % 360;
        return n[(int) Math.round(x / 45.0) % 8];
    }

    void card(RectF r) {
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        f.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0x2EFFFFFF, 0x0DFFFFFF, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, 18 * d, 18 * d, f);
        Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
        s.setStyle(Paint.Style.STROKE);
        s.setStrokeWidth(1 * d);
        s.setColor(0x33FFFFFF);
        cv.drawRoundRect(r, 18 * d, 18 * d, s);
    }

    /** Small rounded label, right-aligned to x. Returns its left edge. */
    float chip(String label, int color, float right, float top) {
        Paint p = text(9.5f, 0xFF04121F, 2);
        float tw = p.measureText(label);
        float h = 15 * d, padX = 6 * d;
        RectF r = new RectF(right - tw - 2 * padX, top, right, top + h);
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(color);
        cv.drawRoundRect(r, h / 2, h / 2, bg);
        cv.drawText(label, r.left + padX, top + h - 4.2f * d, p);
        return r.left;
    }

    // ---------- main ----------

    void draw(Data dt) {
        drawBackground();

        float pad = 12 * d;
        float topH = 104 * d;
        float fH = 60 * d;
        float stripH = 20 * d;

        drawWeatherNow(dt, pad);
        drawForecast(dt, new RectF(pad, topH, W - pad, topH + fH));

        float y0 = topH + fH + 8 * d;
        float y1 = H - pad - stripH;
        float cw = (W - 3 * pad) / 2f;
        if (y1 - y0 > 60 * d) {
            drawSurf(dt, new RectF(pad, y0, pad + cw, y1));
            drawNq(dt, new RectF(2 * pad + cw, y0, W - pad, y1));
        }
        drawStrip(dt, pad, H - pad - 5 * d);
    }

    void drawBackground() {
        float r = 26 * d;
        Path clip = new Path();
        clip.addRoundRect(new RectF(0, 0, W, H), r, r, Path.Direction.CW);
        cv.clipPath(clip);

        Paint bg = new Paint();
        bg.setShader(new LinearGradient(0, 0, W, H,
                new int[]{0xFF07142B, 0xFF0B2F5B, 0xFF0A5674}, null, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, W, H, bg);

        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setShader(new RadialGradient(W * 0.85f, H * 0.08f, W * 0.6f, 0x5533CCFF, 0x0033CCFF, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, W, H, glow);
        glow.setShader(new RadialGradient(W * 0.08f, H * 0.95f, W * 0.55f, 0x3300FFC8, 0x0000FFC8, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, W, H, glow);

        // Soft marble veins
        Random rnd = new Random(7);
        Paint vein = new Paint(Paint.ANTI_ALIAS_FLAG);
        vein.setStyle(Paint.Style.STROKE);
        vein.setMaskFilter(new BlurMaskFilter(1.5f * d, BlurMaskFilter.Blur.NORMAL));
        for (int i = 0; i < 7; i++) {
            vein.setStrokeWidth((0.6f + rnd.nextFloat() * 1.8f) * d);
            vein.setColor(i % 3 == 0 ? 0x22B3E5FC : 0x14FFFFFF);
            Path p = new Path();
            float sy = rnd.nextFloat() * H;
            p.moveTo(-10, sy);
            p.cubicTo(W * 0.3f, sy + (rnd.nextFloat() - 0.5f) * H,
                    W * 0.6f, sy + (rnd.nextFloat() - 0.5f) * H,
                    W + 10, rnd.nextFloat() * H);
            cv.drawPath(p, vein);
        }

        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(1.2f * d);
        border.setColor(0x40FFFFFF);
        cv.drawRoundRect(new RectF(0.6f * d, 0.6f * d, W - 0.6f * d, H - 0.6f * d), r, r, border);
    }

    void drawWeatherNow(Data dt, float pad) {
        float rx = W - pad - 4 * d;
        String emo = Wx.emoji(dt.hasWeather ? dt.code : 3, dt.isDay);
        Paint ep = emojiPaint(42);
        float ew = ep.measureText(emo);
        cv.drawText(emo, rx - ew, pad + 42 * d, ep);

        Paint tp = text(38, WHITE, 0);
        tp.setShadowLayer(8 * d, 0, 0, 0x6600B4FF);
        String t = dt.hasWeather ? deg(dt.temp) : "--°";
        float tw = tp.measureText(t);
        cv.drawText(t, rx - ew - 8 * d - tw, pad + 40 * d, tp);

        Paint cp = text(12.5f, AMBER, 2);
        cp.setTextAlign(Paint.Align.RIGHT);
        cv.drawText(dt.hasWeather ? Wx.label(dt.code) : "Weather loading", rx, pad + 62 * d, cp);

        if (dt.hasWeather && dt.days > 0) {
            Paint sp = text(11, SOFT, 1);
            sp.setTextAlign(Paint.Align.RIGHT);
            String line = "Feels " + deg(dt.feels) + " · H " + deg(dt.dayMax[0]) + " L " + deg(dt.dayMin[0]);
            cv.drawText(line, rx, pad + 78 * d, sp);
        }
    }

    void drawForecast(Data dt, RectF r) {
        card(r);
        if (!dt.hasWeather || dt.days == 0) {
            Paint p = text(11, DIM, 1);
            p.setTextAlign(Paint.Align.CENTER);
            cv.drawText("Forecast unavailable · tap to refresh", r.centerX(), r.centerY() + 4 * d, p);
            return;
        }
        int n = dt.days;
        float colW = r.width() / n;
        for (int i = 0; i < n; i++) {
            float cx = r.left + colW * i + colW / 2;
            Paint dp = text(10.5f, i == 0 ? AQUA : SOFT, 2);
            dp.setTextAlign(Paint.Align.CENTER);
            cv.drawText(dt.dayNames[i], cx, r.top + 15 * d, dp);

            Paint ep = emojiPaint(19);
            String emo = Wx.emoji(dt.dayCodes[i], true);
            cv.drawText(emo, cx - ep.measureText(emo) / 2, r.top + 38 * d, ep);

            Paint hi = text(11.5f, WHITE, 2);
            Paint lo = text(11.5f, DIM, 1);
            String hs = deg(dt.dayMax[i]);
            String ls = " " + deg(dt.dayMin[i]);
            float total = hi.measureText(hs) + lo.measureText(ls);
            float x = cx - total / 2;
            cv.drawText(hs, x, r.top + 53 * d, hi);
            cv.drawText(ls, x + hi.measureText(hs), r.top + 53 * d, lo);

            if (i > 0) {
                Paint sep = new Paint();
                sep.setColor(0x1AFFFFFF);
                float sx = r.left + colW * i;
                cv.drawRect(sx, r.top + 10 * d, sx + 1 * d, r.bottom - 10 * d, sep);
            }
        }
    }

    void drawSurf(Data dt, RectF r) {
        card(r);
        float ip = 12 * d;
        float x = r.left + ip, inner = r.width() - 2 * ip;

        Paint title = text(10.5f, CYAN, 2);
        title.setLetterSpacing(0.08f);
        String tt = "🌊 JORDAN RIVER";
        fit(title, tt, inner * 0.68f);
        cv.drawText(tt, x, r.top + ip + 10 * d, title);

        if (!dt.hasSurf) {
            Paint p = text(11, DIM, 1);
            cv.drawText("Surf data unavailable", x, r.top + ip + 36 * d, p);
            return;
        }

        String rating;
        int rc;
        double h = dt.waveH;
        if (h < 0.4) { rating = "FLAT"; rc = 0xFF90A4AE; }
        else if (h < 0.8) { rating = "SMALL"; rc = 0xFF4FC3F7; }
        else if (h < 1.5) { rating = "FUN"; rc = GREEN; }
        else if (h < 2.5) { rating = "GOOD"; rc = 0xFFFFD54F; }
        else { rating = "BIG"; rc = 0xFFFF7043; }
        chip(rating, rc, r.right - ip, r.top + ip);

        float by = r.top + ip + 40 * d;
        Paint big = text(26, WHITE, 2);
        big.setShadowLayer(8 * d, 0, 0, 0x5500E5FF);
        String hs = one(h);
        cv.drawText(hs, x, by, big);
        float bx = x + big.measureText(hs);
        Paint unit = text(13, SOFT, 1);
        cv.drawText("m", bx + 2 * d, by, unit);
        bx += unit.measureText("m") + 2 * d;
        if (!Double.isNaN(dt.waveP)) {
            Paint per = text(14, CYAN, 2);
            cv.drawText("  " + Math.round(dt.waveP) + "s", bx, by, per);
        }

        StringBuilder sub = new StringBuilder();
        sub.append(compass(dt.waveDir));
        if (!Double.isNaN(dt.swellH)) sub.append(" swell ").append(one(dt.swellH)).append("m");
        if (!Double.isNaN(dt.wind)) {
            sub.append(" · wind ").append(compass(dt.windDir)).append(" ").append(Math.round(dt.wind));
        }
        Paint sp = text(10, SOFT, 1);
        String subS = sub.toString().trim();
        fit(sp, subS, inner);
        cv.drawText(subS, x, r.top + ip + 56 * d, sp);

        // Bar chart: next 48h, one bar per 2 hours
        float top = r.top + ip + 66 * d;
        float bottom = r.bottom - ip - 11 * d;
        int n = dt.surfHourly.length / 2;
        if (bottom - top < 18 * d || n < 2) return;

        double[] v = new double[n];
        double maxV = 0;
        for (int i = 0; i < n; i++) {
            double a = dt.surfHourly[2 * i], b = dt.surfHourly[2 * i + 1];
            double m = Double.isNaN(a) ? b : (Double.isNaN(b) ? a : Math.max(a, b));
            v[i] = Double.isNaN(m) ? 0 : m;
            maxV = Math.max(maxV, v[i]);
        }
        double scale = Math.max(maxV, 1.0);
        float slot = inner / n;
        float bw = slot * 0.7f;
        Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
        bar.setShader(new LinearGradient(0, top, 0, bottom, 0xFF80F5FF, 0xFF1E88E5, Shader.TileMode.CLAMP));
        Paint nowBar = new Paint(Paint.ANTI_ALIAS_FLAG);
        nowBar.setColor(WHITE);
        float ch = bottom - top;
        for (int i = 0; i < n; i++) {
            float bh = Math.max(2 * d, (float) (v[i] / scale) * ch);
            float bxl = x + slot * i + (slot - bw) / 2;
            RectF br = new RectF(bxl, bottom - bh, bxl + bw, bottom);
            cv.drawRoundRect(br, bw * 0.35f, bw * 0.35f, i == 0 ? nowBar : bar);
        }
        Paint pk = text(8.5f, AQUA, 1);
        pk.setTextAlign(Paint.Align.RIGHT);
        cv.drawText("peak " + one(maxV) + "m", r.right - ip, top - 1 * d, pk);

        Paint lb = text(8.5f, DIM, 1);
        float ly = r.bottom - ip + 1 * d;
        cv.drawText("now", x, ly, lb);
        lb.setTextAlign(Paint.Align.CENTER);
        cv.drawText("+24h", x + inner / 2, ly, lb);
        lb.setTextAlign(Paint.Align.RIGHT);
        cv.drawText("+48h", r.right - ip, ly, lb);
    }

    void drawNq(Data dt, RectF r) {
        card(r);
        float ip = 12 * d;
        float x = r.left + ip, inner = r.width() - 2 * ip;

        Paint title = text(10.5f, MINT, 2);
        title.setLetterSpacing(0.08f);
        String tt = "📈 NQ · 5m";
        fit(title, tt, inner * 0.55f);
        cv.drawText(tt, x, r.top + ip + 10 * d, title);

        if (!dt.hasNq && Double.isNaN(dt.nqPrice)) {
            Paint p = text(11, DIM, 1);
            cv.drawText("Market data unavailable", x, r.top + ip + 36 * d, p);
            return;
        }

        double dayChg = dt.nqPrice / dt.nqPrev - 1.0;
        boolean dayUp = Double.isNaN(dayChg) || dayChg >= 0;
        if (!Double.isNaN(dayChg) && !Double.isInfinite(dayChg)) {
            chip(pct(dayChg), dayUp ? GREEN : RED, r.right - ip, r.top + ip);
        }

        Paint big = text(24, WHITE, 2);
        big.setShadowLayer(8 * d, 0, 0, 0x5500E676);
        String ps = Double.isNaN(dt.nqPrice) ? "--" : String.format(Locale.US, "%,.2f", dt.nqPrice);
        fit(big, ps, inner);
        cv.drawText(ps, x, r.top + ip + 40 * d, big);

        double[] c = dt.nqCloses;
        if (c.length < 2) return;
        double first = c[0], last = c[c.length - 1];
        double mn = Double.MAX_VALUE, mx = -Double.MAX_VALUE;
        for (double v : c) { mn = Math.min(mn, v); mx = Math.max(mx, v); }
        boolean up = last >= first;
        int lineColor = up ? GREEN : RED;

        double move = last - first;
        String sub = "10h " + (move >= 0 ? "▲" : "▼") + String.format(Locale.US, "%.2f", Math.abs(move))
                + " · H " + String.format(Locale.US, "%,.0f", mx) + " L " + String.format(Locale.US, "%,.0f", mn);
        Paint sp = text(10, SOFT, 1);
        fit(sp, sub, inner);
        cv.drawText(sub, x, r.top + ip + 56 * d, sp);

        float top = r.top + ip + 66 * d;
        float bottom = r.bottom - ip - 11 * d;
        if (bottom - top < 18 * d) return;
        double range = mx - mn;
        if (range <= 0) range = 1;
        double lo = mn - range * 0.06, hi = mx + range * 0.06;
        float ch = bottom - top;

        Path line = new Path();
        Path area = new Path();
        float px = x, py = bottom;
        for (int i = 0; i < c.length; i++) {
            px = x + inner * i / (c.length - 1f);
            py = bottom - (float) ((c[i] - lo) / (hi - lo)) * ch;
            if (i == 0) { line.moveTo(px, py); area.moveTo(px, bottom); area.lineTo(px, py); }
            else { line.lineTo(px, py); area.lineTo(px, py); }
        }
        area.lineTo(px, bottom);
        area.close();

        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setShader(new LinearGradient(0, top, 0, bottom,
                up ? 0x6600E676 : 0x66FF5252, 0x00000000, Shader.TileMode.CLAMP));
        cv.drawPath(area, fill);

        // Dashed line at the 10h-ago price
        float fy = bottom - (float) ((first - lo) / (hi - lo)) * ch;
        Paint dash = new Paint(Paint.ANTI_ALIAS_FLAG);
        dash.setStyle(Paint.Style.STROKE);
        dash.setStrokeWidth(1 * d);
        dash.setColor(0x55FFFFFF);
        dash.setPathEffect(new DashPathEffect(new float[]{4 * d, 4 * d}, 0));
        Path dp = new Path();
        dp.moveTo(x, fy);
        dp.lineTo(x + inner, fy);
        cv.drawPath(dp, dash);

        Paint lp = new Paint(Paint.ANTI_ALIAS_FLAG);
        lp.setStyle(Paint.Style.STROKE);
        lp.setStrokeWidth(1.8f * d);
        lp.setStrokeJoin(Paint.Join.ROUND);
        lp.setColor(lineColor);
        cv.drawPath(line, lp);

        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        dot.setColor((lineColor & 0x00FFFFFF) | 0x55000000);
        cv.drawCircle(px, py, 6 * d, dot);
        dot.setColor(WHITE);
        cv.drawCircle(px, py, 2.6f * d, dot);

        Paint lb = text(8.5f, DIM, 1);
        float ly = r.bottom - ip + 1 * d;
        cv.drawText("-10h", x, ly, lb);
        lb.setTextAlign(Paint.Align.RIGHT);
        cv.drawText("now", r.right - ip, ly, lb);
    }

    void drawStrip(Data dt, float pad, float baseline) {
        Paint up = new Paint(Paint.ANTI_ALIAS_FLAG);
        String time = "⟳ " + new SimpleDateFormat("h:mm a", Locale.US).format(new Date(dt.updated));
        Paint tp = text(9.5f, DIM, 1);
        tp.setTextAlign(Paint.Align.RIGHT);
        cv.drawText(time, W - pad - 4 * d, baseline, tp);
        float avail = W - 2 * pad - tp.measureText(time) - 16 * d;

        float size = 11;
        Paint name = text(size, SOFT, 2);
        Paint val = text(size, WHITE, 2);
        float total = 0;
        for (int i = 0; i < dt.qNames.length; i++) {
            total += name.measureText(dt.qNames[i] + " ") + val.measureText(pct(dt.qChg[i])) + 12 * d;
        }
        if (total > avail && total > 0) {
            float k = avail / total;
            name.setTextSize(name.getTextSize() * k);
            val.setTextSize(val.getTextSize() * k);
        }
        float x = pad + 4 * d;
        for (int i = 0; i < dt.qNames.length; i++) {
            String n = dt.qNames[i] + " ";
            cv.drawText(n, x, baseline, name);
            x += name.measureText(n);
            double c = dt.qChg[i];
            val.setColor(Double.isNaN(c) ? DIM : (c >= 0 ? GREEN : RED));
            String v = pct(c);
            cv.drawText(v, x, baseline, val);
            x += val.measureText(v) + 12 * d * (val.getTextSize() / (size * d));
        }
    }
}
