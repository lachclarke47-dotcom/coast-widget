package ca.lach.coastwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.RemoteViews;

/**
 * Home screen widget. Markets refresh every minute while the screen is on
 * (non-waking alarm, so it pauses when the phone sleeps). Weather and surf
 * refresh every 30 min. Tapping forces a full refresh.
 */
public class CoastWidget extends AppWidgetProvider {

    static final String ACTION_REFRESH = "ca.lach.coastwidget.REFRESH";
    static final String ACTION_TICK = "ca.lach.coastwidget.TICK";

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        schedule(c);
        refresh(c, ids, false);
    }

    @Override
    public void onEnabled(Context c) {
        schedule(c);
    }

    @Override
    public void onDisabled(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(tickIntent(c));
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        refresh(c, new int[]{id}, false);
    }

    static PendingIntent tickIntent(Context c) {
        Intent i = new Intent(c, CoastWidget.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(c, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Every minute, but only while the phone is awake (RTC does not wake it). */
    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        am.setRepeating(AlarmManager.RTC, System.currentTimeMillis() + 60_000, 60_000, tickIntent(c));
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        String a = i.getAction();
        if (ACTION_REFRESH.equals(a) || ACTION_TICK.equals(a)) {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, CoastWidget.class));
            if (ids != null && ids.length > 0) {
                if (ACTION_REFRESH.equals(a)) schedule(c);
                refresh(c, ids, ACTION_REFRESH.equals(a));
            }
        }
    }

    private void refresh(Context c, int[] ids, boolean force) {
        final PendingResult pr = goAsync();
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            try {
                Data dt = DataFetcher.fetch(app, force);
                AppWidgetManager m = AppWidgetManager.getInstance(app);
                for (int id : ids) draw(app, m, id, dt);
            } catch (Throwable ignored) {
            } finally {
                pr.finish();
            }
        }).start();
    }

    static void draw(Context c, AppWidgetManager m, int id, Data dt) {
        float density = c.getResources().getDisplayMetrics().density;
        Bundle o = m.getAppWidgetOptions(id);
        int wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (wDp <= 0) wDp = 360;
        if (hDp <= 0) hDp = 300;

        // Keep the bitmap a sensible size for the launcher
        float scale = density;
        double px = (double) wDp * hDp * scale * scale;
        if (px > 1_800_000) scale *= (float) Math.sqrt(1_800_000 / px);
        int w = Math.max(1, Math.round(wDp * scale));
        int h = Math.max(1, Math.round(hDp * scale));

        Bitmap bmp = Renderer.render(dt, w, h, scale);

        int layout = hDp >= Renderer.FULL_MIN_DP ? R.layout.widget : R.layout.widget_compact;
        RemoteViews rv = new RemoteViews(c.getPackageName(), layout);
        rv.setImageViewBitmap(R.id.canvas, bmp);
        Intent i = new Intent(c, CoastWidget.class).setAction(ACTION_REFRESH);
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.root, pi);
        m.updateAppWidget(id, rv);
    }
}
