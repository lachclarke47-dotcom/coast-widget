package ca.lach.coastwidget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** Pulls weather, surf and market data. Falls back to the last good copy if a fetch fails. */
public class DataFetcher {

    // Jordan River, BC
    static final String WEATHER = "https://api.open-meteo.com/v1/forecast?latitude=48.42&longitude=-124.05"
            + "&current=temperature_2m,apparent_temperature,weather_code,is_day,wind_speed_10m,wind_direction_10m"
            + "&daily=weather_code,temperature_2m_max,temperature_2m_min"
            + "&timezone=America%2FVancouver&forecast_days=6";

    // A point just offshore of the Jordan River break
    static final String SURF = "https://marine-api.open-meteo.com/v1/marine?latitude=48.38&longitude=-124.08"
            + "&current=wave_height,wave_period,wave_direction,swell_wave_height"
            + "&hourly=wave_height&timezone=America%2FVancouver&forecast_days=3";

    // Backup point further out in the strait, in case the nearshore cell is empty
    static final String SURF2 = "https://marine-api.open-meteo.com/v1/marine?latitude=48.30&longitude=-124.20"
            + "&current=wave_height,wave_period,wave_direction,swell_wave_height"
            + "&hourly=wave_height&timezone=America%2FVancouver&forecast_days=3";

    static final String YF = "https://query1.finance.yahoo.com/v8/finance/chart/";
    static final String NQ_CHART = YF + "NQ%3DF?interval=5m&range=2d";
    static final String Q_NQ = YF + "NQ%3DF?interval=1d&range=1d";
    static final String Q_NDX = YF + "%5ENDX?interval=1d&range=1d";
    static final String Q_SPX = YF + "%5EGSPC?interval=1d&range=1d";
    static final String Q_OIL = YF + "CL%3DF?interval=1d&range=1d";

    static final long MARKET_AGE = 50_000;        // markets: refetch after 50 s
    static final long SLOW_AGE = 30 * 60_000;     // weather and surf: refetch after 30 min

    /** Returns cached data if it is newer than maxAgeMs, otherwise fetches fresh. */
    static String get(Context c, String url, long maxAgeMs) {
        SharedPreferences sp = c.getSharedPreferences("cache", Context.MODE_PRIVATE);
        String cached = sp.getString(url, null);
        long age = System.currentTimeMillis() - sp.getLong(url + "#t", 0);
        if (cached != null && age < maxAgeMs) return cached;
        try {
            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setConnectTimeout(5000);
            con.setReadTimeout(6000);
            con.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36");
            con.setRequestProperty("Accept", "application/json");
            int code = con.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            con.disconnect();
            String s = sb.toString();
            sp.edit().putString(url, s).putLong(url + "#t", System.currentTimeMillis()).apply();
            return s;
        } catch (Exception e) {
            return sp.getString(url, null);
        }
    }

    /** force = true refetches everything (tap to refresh). */
    static Data fetch(Context c, boolean force) {
        String[] urls = {WEATHER, SURF, NQ_CHART, Q_NQ, Q_NDX, Q_SPX, Q_OIL, SURF2};
        long slow = force ? 0 : SLOW_AGE;
        long fast = force ? 0 : MARKET_AGE;
        long[] ages = {slow, slow, fast, fast, fast, fast, fast, slow};
        ExecutorService ex = Executors.newFixedThreadPool(urls.length);
        List<Future<String>> fs = new ArrayList<>();
        for (int i = 0; i < urls.length; i++) {
            final String u = urls[i];
            final long a = ages[i];
            fs.add(ex.submit(() -> get(c, u, a)));
        }
        String[] res = new String[urls.length];
        long deadline = System.currentTimeMillis() + 8500;
        for (int i = 0; i < urls.length; i++) {
            try {
                long wait = Math.max(1, deadline - System.currentTimeMillis());
                res[i] = fs.get(i).get(wait, TimeUnit.MILLISECONDS);
            } catch (Exception e) {
                res[i] = c.getSharedPreferences("cache", Context.MODE_PRIVATE).getString(urls[i], null);
            }
        }
        ex.shutdownNow();

        Data d = new Data();
        try { parseWeather(d, res[0]); } catch (Exception ignored) { }
        try { parseSurf(d, res[1]); } catch (Exception ignored) { }
        if (!d.hasSurf) {
            try { parseSurf(d, res[7]); } catch (Exception ignored) { }
        }
        try { parseNqChart(d, res[2]); } catch (Exception ignored) { }
        try {
            double[] q = parseQuote(res[3]);
            if (!Double.isNaN(q[0])) d.nqPrice = q[0];
            d.nqPrev = q[1];
        } catch (Exception ignored) { }
        for (int i = 0; i < 3; i++) {
            try {
                double[] q = parseQuote(res[4 + i]);
                d.qChg[i] = q[0] / q[1] - 1.0;
            } catch (Exception ignored) { }
        }
        d.updated = System.currentTimeMillis();
        return d;
    }

    static void parseWeather(Data d, String s) throws Exception {
        if (s == null) return;
        JSONObject o = new JSONObject(s);
        JSONObject cur = o.getJSONObject("current");
        d.temp = cur.optDouble("temperature_2m", Double.NaN);
        d.feels = cur.optDouble("apparent_temperature", Double.NaN);
        d.code = cur.optInt("weather_code", 3);
        d.isDay = cur.optInt("is_day", 1) == 1;
        d.wind = cur.optDouble("wind_speed_10m", Double.NaN);
        d.windDir = cur.optDouble("wind_direction_10m", Double.NaN);
        JSONObject daily = o.getJSONObject("daily");
        JSONArray time = daily.getJSONArray("time");
        JSONArray codes = daily.getJSONArray("weather_code");
        JSONArray max = daily.getJSONArray("temperature_2m_max");
        JSONArray min = daily.getJSONArray("temperature_2m_min");
        int n = Math.min(5, time.length());
        for (int i = 0; i < n; i++) {
            if (i == 0) {
                d.dayNames[i] = "Today";
            } else {
                LocalDate ld = LocalDate.parse(time.getString(i));
                d.dayNames[i] = ld.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.US);
            }
            d.dayCodes[i] = codes.optInt(i, 3);
            d.dayMax[i] = max.optDouble(i, Double.NaN);
            d.dayMin[i] = min.optDouble(i, Double.NaN);
        }
        d.days = n;
        d.hasWeather = !Double.isNaN(d.temp);
    }

    static void parseSurf(Data d, String s) throws Exception {
        if (s == null) return;
        JSONObject o = new JSONObject(s);
        JSONObject cur = o.getJSONObject("current");
        d.waveH = cur.optDouble("wave_height", Double.NaN);
        d.waveP = cur.optDouble("wave_period", Double.NaN);
        d.waveDir = cur.optDouble("wave_direction", Double.NaN);
        d.swellH = cur.optDouble("swell_wave_height", Double.NaN);
        String now = cur.optString("time", "");
        String nowHour = now.length() >= 13 ? now.substring(0, 13) : "";

        JSONObject hourly = o.getJSONObject("hourly");
        JSONArray time = hourly.getJSONArray("time");
        JSONArray wh = hourly.getJSONArray("wave_height");
        int start = 0;
        for (int i = 0; i < time.length(); i++) {
            if (time.getString(i).startsWith(nowHour)) { start = i; break; }
        }
        int n = Math.min(48, wh.length() - start);
        if (n < 0) n = 0;
        d.surfHourly = new double[n];
        for (int i = 0; i < n; i++) d.surfHourly[i] = wh.optDouble(start + i, Double.NaN);
        if (Double.isNaN(d.waveH) && n > 0) d.waveH = d.surfHourly[0];
        d.hasSurf = !Double.isNaN(d.waveH);
    }

    static void parseNqChart(Data d, String s) throws Exception {
        if (s == null) return;
        JSONObject r = new JSONObject(s).getJSONObject("chart").getJSONArray("result").getJSONObject(0);
        JSONObject meta = r.getJSONObject("meta");
        d.nqPrice = meta.optDouble("regularMarketPrice", Double.NaN);
        JSONArray closes = r.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).getJSONArray("close");
        List<Double> vals = new ArrayList<>();
        for (int i = 0; i < closes.length(); i++) {
            if (!closes.isNull(i)) vals.add(closes.getDouble(i));
        }
        int from = Math.max(0, vals.size() - 120); // 120 x 5 min = 10 hours
        d.nqCloses = new double[vals.size() - from];
        for (int i = from; i < vals.size(); i++) d.nqCloses[i - from] = vals.get(i);
        if (Double.isNaN(d.nqPrice) && d.nqCloses.length > 0) d.nqPrice = d.nqCloses[d.nqCloses.length - 1];
        d.hasNq = d.nqCloses.length > 1;
    }

    /** Returns {price, previousClose}. */
    static double[] parseQuote(String s) throws Exception {
        JSONObject meta = new JSONObject(s).getJSONObject("chart").getJSONArray("result")
                .getJSONObject(0).getJSONObject("meta");
        double p = meta.optDouble("regularMarketPrice", Double.NaN);
        double prev = meta.optDouble("chartPreviousClose", Double.NaN);
        if (Double.isNaN(prev)) prev = meta.optDouble("previousClose", Double.NaN);
        return new double[]{p, prev};
    }
}
